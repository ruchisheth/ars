<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;

use App\Http\Requests;

use Illuminate\Support\Collection;

use Validator;

use App\Site;

use App\Client;

use App\AppData;

use App\Chain;

use App\FieldRep;

use App\FieldRep_Org;

use App\Setting;

use App\_List;

use App\Project;

use App\Contact;

use App\PrefBan;

use App\Assignment;

use DB;

use Excel;

use Datatables;

use Illuminate\Support\Facades\Input;

use Illuminate\Support\Facades\Redirect;

class ImportController extends Controller
{
	public function index(){

		return view('admin.imports.imports');
	}

	public function Import(Request $request)
	{
		\Debugbar::disable();
		$this->validate($request, [
			"importfile"   =>  "required",
			]);

		$modelName = $request->input('entity');
		$res = null;
		
		if($modelName == 'Clients/Chains'){		 	
			$obj = new Client;
			$res = $obj->importData($request);
		}	
		if($modelName == 'FieldRep'){		 	
			$obj = new Fieldrep;
			$res = $obj->importData($request);
		}
		if($modelName == 'Site'){		 	
			$obj = new Site;
			$res = $obj->importData($request);
		}
		if($modelName == 'FieldRep_Org'){		

			$obj = new FieldRep_Org;		 
			$res = $obj->importData($request);
		}
		if($modelName == 'Assignment'){		

			$obj = new Assignment;		 
			$res = $obj->importData($request);
		}
		if($modelName == 'PrefBan'){		
			$obj = new PrefBan;		 
			$res = $obj->importData($request);
		}
		if($res['error_status'] == true){
			$message = '';
			//dd($res);
			//dd(count($res['err']));
			if(count($res['err'] > 0)){
				foreach($res['err'] as $key => $error){
					if(isset($error['row_number'])){
						foreach($error['message'] as  $err_message){
							$message .= 'Erorr at row '.$error['row_number'].' : '. $err_message.'<br>';
						}
					}else{
						$message .= $error['message'];
					}
				}
				return response()->json([ 'message' => $message ], 422);
			}
		}else{
			return response()->json(array(
				"status" => "success",
				"message"=>"Data Imported Successfully",
				)); 
			
		}
		\Debugbar::enable();
	}
}
