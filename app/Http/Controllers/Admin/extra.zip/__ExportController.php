<?php

namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Collection;
use App\Http\Requests;
use Illuminate\Support\Facades\Input;
use App\Http\AppHelper;
use Response;
use View;
use App\Client;
use App\Chain;
use App\Project;
use App\surveys;
use App\Assignment;
use App\Round;
use App\Site;
use DB;
use App\surveys_template;
use Excel;

class ExportController extends Controller
{
	public function exportView(Request $request,$entity = ''){

		if($entity == ''){
			return view('admin.export.export');
		}else{
			$client_list = ['' => 'Select Client'] + Client::lists('client_name','id')->all();
			$view = View::make('admin.export.export_'.$entity,['client_list' => $client_list]);
			if($request->ajax()) {
				$sections = $view->renderSections(); // returns an associative array of 'content', 'head' and 'footer'
	      return $sections['content']; // this will only return whats in the content section
	    }
	    return $view;
	  }
	  /*-----------------------------------------------*/
		//view = View::make('admin.export.export', ['name' => 'Rose']);
		//$contents = (string) $view;
		//or
		//$contents = $view->render();
		//return $contents;
	  /*-----------------------------------------------*/
		// $view = View::make('admin.export.export');
    // $sections = $view->renderSections(); // returns an associative array of 'content', 'head' and 'footer'
    // return $sections['content']; // this will only return whats in the content section
	}

	public function exportSurveyData(Request $request){
		$this->validate($request, [
			"client_id"   =>  "required",
			"project_id"   =>  "required",
			"round_id"   =>  "required",
			],
			[
			"client_id.required" => "The Client Id field is required.",
			"project_id.required" => "The Project field is required.",
			"round_id.required" => "The Round Id field is required.",
			]);

		$is_approved_survey_only = $request->has('approved_survey');
		$is_unexported_survey_only = $request->has('unexported_survey');

		
		//Get question to export and remove blank values
		if($request->has('question_id')){
			$export_question = array_filter($request->get('question_id'));
		}
		$round = Round::find($request->get('round_id'));
		$project = Project::find($request->get('project_id'));
		$filename = format_code($round->id)."-".$round->round_name;
		//$assignments = Assignment::where('round_id', $request->get('round_id'))->get(['id']);
		$assignments = Assignment::where('round_id', $request->get('round_id'));

		if($is_approved_survey_only){
			$assignments->where('is_approved', '=', true);
		}

		$assignments = $assignments->get(['id']);


		if($assignments->isEmpty()) {
			return redirect('/exports/survey')->withErrors('Your request has no result');
		}

		$assignments = array_map('current',$assignments->toArray());

		$survey_datas = surveys::whereIn('assignment_id',$assignments)->whereIn('status', ['2','4']);

		if($is_unexported_survey_only){
			$survey_datas->where('is_exported', '=', false);
		}

		$survey_datas = $survey_datas->get();
		

		if($survey_datas->isEmpty()) {
			return redirect('/exports/survey')->withErrors('Your request has no result');
		}

		$table;
		$columns[] = "Code";
		$setColumn = false;
		
		foreach($survey_datas as $key => $survey_data){
			$survey_exported[] =  $survey_data->id;

			// Fetch site code of survey (assignment code);
			$surveys = surveys::find($survey_data->id);
			$site_code = $surveys->assignments->sites->site_code;
			$chain_code = $surveys->assignments->rounds->projects->chains->id;
			$assignment = Assignment::find($surveys->assignments->id);
			$surveys_template = surveys_template::find($survey_data->template_id);
			

			$table[$key]['Survey No.'] = $site_code;
			$table[$key]['Project Name'] =  $project->project_name;
			$table[$key]['Round Name'] =  $round->round_name;
			$table[$key]['Assignment Code'] =  $site_code;
			$table[$key]['Site Code'] =  $site_code;
			$table[$key]['Chain Code'] =  $chain_code;
			$table[$key]['Template Code'] =  $survey_data->template_id;
			$table[$key]['Template name'] =  $surveys_template->template_name;
			$table[$key]['Schedule Date'] =  date_format(\Carbon::parse($assignment->getAssignmentScheduleDate()),AppHelper::DATE_EXPORT_FORMAT);
			$table[$key]['Deadline Date'] =  date_format(\Carbon::parse($assignment->getAssignmentEndDate()),AppHelper::DATE_EXPORT_FORMAT);
			$datas = unserialize($survey_data->keypairs);



			//reindex question array start from index 1 instead 0
			//$datas = array_filter(array_merge(array(0), $datas));
			if(!empty($export_question)){
				$export_questions = array_flip($export_question);
				$datas = array_intersect_key($datas, $export_questions);
			}

			foreach ($datas as $d_key => $d_value) {
				$col_name = $d_value['que_no'];				
				if($d_value['type'] == 'file'){

					$col_val = explode(',',$d_value['ans']);
					$col_val = implode($col_val,' ; ');
				}
				else if($d_value['type'] == 'checkbox' || $d_value['type'] == 'radio'){
					if($d_value['ans'] == ""){
						$d_value['ans'] = "0";
						$col_val = $d_value['ans'];
					}
					$col_val = $d_value['ans'];
				}else if($d_value['type'] == 'date'){
					$date = $d_value['ans'];

					
					$date = \Carbon::parse($date);
					$date = date_format($date,AppHelper::DATE_EXPORT_FORMAT);
					$col_val = $date;
				}
				else{
					$col_val = $d_value['ans'];
				}

				
				$col_name = "Q.".$d_key.' '.$d_value['ques'];

				

				if($setColumn == false){
					$columns[] = $col_name;
				}

        $table[$key][$col_name] = $col_val; // question number
      }
      $setColumn = true;
    }

    //unset($columns[1]);
    //unset($table['template_name_']);

    $table = Collection::make($table);

    $table = $table->sortBy('Site Code');
    //dd($table);
    

    /*
    / Mark Surveys as Exported
    */
    surveys::whereIn('id', $survey_exported)->update(['is_exported' => true]);

    Excel::create($filename,function($excel) use ($table){
    	$excel->sheet('Sheet 1',function($sheet) use ($table){
    		//$sheet->freezeFirstRowAndColumn();
    		$sheet->fromArray($table);
    	});
    })->export('csv');

    return redirect('export/survey')->with('success', 'Survey Data Exported!');
  }

  public function getClientProject(Request $request){
  	$option = $request->get('depdrop_parents')[0];
  	if($option != ""){
  		$client = Client::find($option);
  		$project = $client->projects();
  		$projects = $project->get(['project_name','projects.id']);
  		if(!$projects->isEmpty()){
  			$projs = [];
  			foreach ($projects as $key => $proj) {
  				$projs[] = ['id' => $proj->id, 'name' => $proj->project_name];
  			}
  			return json_encode(['output'=>$projs, 'selected'=>'']);
  		}
  		// else{
  		// 	return json_encode(['output'=>'', 'selected'=>'']);
  		// }
  	}
  	return json_encode(['output'=>'', 'selected'=>'']);
  	//return Response::make($project->get(['projects.id','project_name']));
  }

  public function getProjectRound(Request $request){
  	$option = $request->get('depdrop_parents')[0];
  	$params = $request->get('depdrop_all_params');  	
  	if($option != ""){
  		$project = Project::find($option);
  		$rounds = $project->rounds()->get(['id','round_name']);
  		if(!$rounds->isEmpty()){
  			$out_rounds = [];
  			foreach ($rounds as $key => $round) {
  				$out_rounds[] = ['id' => $round->id, 'name' => $round->round_name];
  			}
  			return json_encode(['output'=>$out_rounds, 'selected'=>'']);
  		}

  	}//if over
  	else if(array_has($params, 'all_round')){
  		$rounds = Round::orderBy('id','desc')->get();
  		$out_rounds = [];
  		foreach ($rounds as $key => $round) {
  			$out_rounds[] = ['id' => $round->id, 'name' => $round->round_name];
  		}
  		return json_encode(['output'=>$out_rounds, 'selected'=>'']);
  	}
  	return json_encode(['output'=>'', 'selected'=>'']);
  	//return Response::make($round->get(['id','round_name']));
  }

  public function getProjectSiteCode(Request $request){
  	$option = $request->get('depdrop_parents')[0];
  	$params = $request->get('depdrop_all_params');

  	if($option != ""){
  		$project = Project::find($option);
  		$sites = $project->chains->sites()->distinct()->orderBy(DB::raw('lpad(trim(site_code), 10, 0)'), 'asc')->get(['site_code']);
  		if(!$sites->isEmpty()){
  			$out_site_codes = [];
  			foreach ($sites as $key => $site) {
  				$out_site_codes[] = ['id' => $site->site_code, 'name' => $site->site_code];
  			}
  			return json_encode(['output'=> $out_site_codes, 'selected'=>'']);
  		}

  	}//if over
  	else if(array_has($params, 'all_sitecodes')){
  		$sites = Site::select(['site_code'])->orderBy(DB::raw('lpad(trim(site_code), 10, 0)'), 'acs')->distinct()->get();
  		$out_site_codes = [];
  		foreach ($sites as $key => $site) {
  			$out_site_codes[] = ['id' => $site->site_code, 'name' => $site->site_code];
  		}
  		return json_encode(['output'=> $out_site_codes, 'selected'=>'']);
  	}
  	return json_encode(['output'=>'', 'selected'=>'']);
  	//return Response::make($round->get(['id','round_name']));
  }

  public function getRoundQuestion(Request $request){
  	$round_id = $request->get('depdrop_parents')[0];
  	if($round_id != ""){
  		$round = Round::find($round_id);
  		$survey = $round->surveys;
  		$surveys = $round->surveys();
  		
  		if(!$survey->isEmpty()){
  			$questions = [];
  			//$survey = $survey->first()->where('keypairs', '!=', '')->get();
  			$surveys = $surveys->where('keypairs', '!=', '');
  			$question_data = $survey->first()->keypairs;
  			$question_data = unserialize($question_data);
  			// if($question_data[0]['que_no'] == 'template_name'){
  			// 	unset($question_data[0]);
  			// }
  			$question_data = array_filter(array_merge(array(0), $question_data));
  			foreach($question_data as $qkey => $question){
  				$questions[] = ['id' => $qkey, 'name' => "Q.".$qkey." ".$question['ques']];
  			}
  			return json_encode(['output'=>$questions, 'selected'=>'']);
  		}
  	}
  	return json_encode(['output'=>'', 'selected'=>'']);
  	//return Response::make($round->get(['id','round_name']));
  }
}
